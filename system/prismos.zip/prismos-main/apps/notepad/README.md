
# ![](../../images/icons/notepad-32x32.png) Notepad

Try it [as part of 98](https://98.js.org/) or [standalone](https://98.js.org/programs/notepad/)


### TODO

* Determine copy/cut/paste-ability when opening menus and keep relevant menu items enabled (currently the menus update at several other times, and become disabled), or have the menus not take focus so that the the copy/cut/paste-ability is uneffected by navigating the menus

* Help > About Notepad
  * Link back to 98 in case the app is opened standalone

* Search (altho you can use the browser's <kbd>Ctrl+F</kbd>)

* Edit > Set Font
